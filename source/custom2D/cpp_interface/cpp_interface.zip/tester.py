import ctypes
import sys
import os 
import numpy
import subprocess
import time
import psutil


c_float_p = ctypes.POINTER(ctypes.c_float)
c_float_array = numpy.ctypeslib.ndpointer(dtype=ctypes.c_float, ndim=1, flags="C_CONTIGUOUS")
def setup_dll_handle():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    os.add_dll_directory(dir_path)
    handle = ctypes.CDLL(dir_path + "/test.dll", winmode=0)     
    handle.set_array.argtypes = [c_float_array]
    handle.get_array.argtypes = [c_float_array]
    handle.get_array_pointer.restype = ctypes.c_int64
    handle.setup_array_pointer.argtypes = [ctypes.c_int64, ctypes.c_int]
    handle.get_array_child.argtypes = [c_float_array]


    return handle












def child_main():

    
    my_float_array = numpy.full(100, numpy.nan, dtype=ctypes.c_float)
    handle = setup_dll_handle()
    handle.setup_array_pointer(int(sys.argv[1]), int(sys.argv[2]))


    while psutil.pid_exists(int(sys.argv[2])):
        handle.get_array_child(my_float_array)
        print(my_float_array)
        time.sleep(0)



def main():

    os.system("g++ -fPIC -shared -o test.dll test.cpp") #compile c++
    my_float_array = numpy.full(100, numpy.nan, dtype=ctypes.c_float)
    handle = setup_dll_handle()
    handle.dll_main()
    print("here")



    array_pointer = handle.get_array_pointer()


    child_proc = subprocess.Popen(f"python tester.py {array_pointer} {os.getpid()}", text=True, shell=True, stdin=subprocess.PIPE, stdout=sys.stdout, stderr=sys.stderr)
    child_proc.stdin.write("1\n")
    child_proc.stdin.flush()

    poll = None
    for i in range(100):
        my_float_array[i] = i
        handle.set_array(my_float_array)
        time.sleep(0)

    time.sleep(5)
    #while poll == None:
    #    poll = child_proc.poll()
    #    time.sleep(1.5)
        #handle.get_array(my_float_array)
        #print(my_float_array)




time.sleep(1)


signal = sys.stdin.readline()
print(signal)
if signal == "0\n":
    main()
elif signal == "1\n":
    child_main()
else:
    print("bad")